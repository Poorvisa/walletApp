package com.wallet.app.exception;

public class AdminException extends Exception {

	public AdminException(String string) {
		super(string);
	}
	
	

}
