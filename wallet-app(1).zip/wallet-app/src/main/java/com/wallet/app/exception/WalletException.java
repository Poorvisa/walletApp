package com.wallet.app.exception;

public class WalletException extends Exception{
	//String message;

	public WalletException(String message) {
		super(message);
	
	}
	

}
