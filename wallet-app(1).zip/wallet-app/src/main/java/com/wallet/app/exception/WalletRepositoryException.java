package com.wallet.app.exception;

public class WalletRepositoryException extends Exception{
	
	

	public WalletRepositoryException(String msg) {
		super(msg);
		
	}
	

}
